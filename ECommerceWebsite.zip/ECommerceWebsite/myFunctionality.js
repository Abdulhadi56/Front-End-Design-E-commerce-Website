// ================== JAVASCRIPT SECTION ==================
// Save this as script.js

document.getElementById('quote-form').addEventListener('submit', function(e) {
  e.preventDefault();
  alert('Your inquiry has been submitted!');
});
